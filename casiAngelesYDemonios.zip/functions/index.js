const functions = require('firebase-functions');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const formRoutes = require('./routes/formRoutes');
const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const messageRoutes = require('./routes/messageRoutes');
const publicidadRoutes = require('./routes/publicidad');
const reportRoutes = require('./routes/reportRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Use form routes
app.use('/api', formRoutes);

// Use user routes
app.use('/api', userRoutes);

// Use auth routes
app.use('/api', authRoutes);

// Use message routes
app.use('/api', messageRoutes);

// Use publicidad routes
app.use('/api/publicidad', publicidadRoutes);

// Use report routes
app.use('/api/reports', reportRoutes);

// Catch-all route for handling 404 errors
app.use((req, res, next) => {
  res.status(404).send('Page Not Found');
});

exports.api = functions.https.onRequest(app);
